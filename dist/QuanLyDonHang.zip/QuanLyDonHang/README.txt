QuanLyDonHang - Phần mềm Quản lý đơn hàng

Hướng dẫn cài đặt:
1. Chạy file QuanLyDonHang.exe với quyền Administrator
2. Chờ chương trình khởi động lần đầu tiên
3. Sử dụng bình thường

Lưu ý:
- Cần quyền Administrator để chạy chương trình
- Không xóa các thư mục assets và logs
- Nếu có lỗi, vui lòng kiểm tra file logs